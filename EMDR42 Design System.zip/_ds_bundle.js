/* @ds-bundle: {"format":3,"namespace":"EMDR42DesignSystem_d3a71e","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"Card","sourcePath":"components/cards/Card.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"Disclaimer","sourcePath":"components/feedback/Disclaimer.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"LandingNav","sourcePath":"ui_kits/landing/LandingPage.jsx"},{"name":"LandingHero","sourcePath":"ui_kits/landing/LandingPage.jsx"},{"name":"LandingFeatures","sourcePath":"ui_kits/landing/LandingPage.jsx"},{"name":"LandingCta","sourcePath":"ui_kits/landing/LandingPage.jsx"},{"name":"LandingFooter","sourcePath":"ui_kits/landing/LandingPage.jsx"},{"name":"LandingPage","sourcePath":"ui_kits/landing/LandingPage.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"6093075ebb86","components/cards/Card.jsx":"8c34649b550b","components/feedback/Badge.jsx":"0c9703f40371","components/feedback/Disclaimer.jsx":"a4f9838269bb","components/forms/Input.jsx":"e87ee59607fa","ui_kits/landing/LandingPage.jsx":"30ab14f548e0"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EMDR42DesignSystem_d3a71e = window.EMDR42DesignSystem_d3a71e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
/**
 * Кнопка EMDR42. Primary — единственный «светящийся» элемент
 * (ореол лунного света через box-shadow, не неон).
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  href,
  onClick,
  type = 'button',
  style
}) {
  const className = `e-btn e-btn--${variant} e-btn--${size}`;
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, loading && /*#__PURE__*/React.createElement("span", {
    className: "e-btn__spinner",
    "aria-hidden": "true"
  }), children);
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", {
      className: className,
      href: href,
      onClick: onClick,
      style: style
    }, inner);
  }
  return /*#__PURE__*/React.createElement("button", {
    className: className,
    disabled: disabled || loading,
    onClick: onClick,
    type: type,
    style: style
  }, inner);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/cards/Card.jsx
try { (() => {
/**
 * Карточка-поверхность со «светом луны на ребре» (светлая кромка сверху).
 * FeatureCard-режим: icon + title + text.
 */
function Card({
  icon,
  title,
  children,
  hoverable = true,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `e-card${hoverable ? ' e-card--hoverable' : ''}`,
    style: style
  }, icon && /*#__PURE__*/React.createElement("div", {
    className: "e-card__icon",
    "aria-hidden": "true"
  }, icon), title && /*#__PURE__*/React.createElement("h3", {
    className: "e-card__title"
  }, title), typeof children === 'string' ? /*#__PURE__*/React.createElement("p", {
    className: "e-card__text"
  }, children) : children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/Card.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
/**
 * Бейдж-пилюля. Все варианты приглушённые — никаких кричащих статусов.
 */
function Badge({
  children,
  variant = 'default',
  style
}) {
  const cls = variant === 'default' ? 'e-badge' : `e-badge e-badge--${variant}`;
  return /*#__PURE__*/React.createElement("span", {
    className: cls,
    style: style
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Disclaimer.jsx
try { (() => {
/**
 * Медицинский дисклеймер — обязательный смысловой якорь доверия.
 * Спокойная «тёплая» карточка (умбра/охра берега): заметная, но не тревожная.
 */
function Disclaimer({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "e-disclaimer",
    role: "note",
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    className: "e-disclaimer__icon",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"
  }))), /*#__PURE__*/React.createElement("div", null, children || /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("strong", null, "\u0412\u0430\u0436\u043D\u043E:"), " EMDR-AI \u2014 \u0432\u0441\u043F\u043E\u043C\u043E\u0433\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442 \u0438 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u0443\u044E \u043F\u0441\u0438\u0445\u043E\u0442\u0435\u0440\u0430\u043F\u0435\u0432\u0442\u0438\u0447\u0435\u0441\u043A\u0443\u044E \u043F\u043E\u043C\u043E\u0449\u044C. \u0412 \u043A\u0440\u0438\u0437\u0438\u0441\u043D\u043E\u0439 \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u0438 \u0437\u0432\u043E\u043D\u0438\u0442\u0435:", ' ', "RU ", /*#__PURE__*/React.createElement("strong", null, "8-800-2000-122"), " \xB7 US ", /*#__PURE__*/React.createElement("strong", null, "988"), " \xB7 UK ", /*#__PURE__*/React.createElement("strong", null, "116 123"), " \xB7", ' ', /*#__PURE__*/React.createElement("a", {
    href: "https://www.befrienders.org",
    target: "_blank",
    rel: "noopener noreferrer"
  }, "befrienders.org"), ".")));
}
Object.assign(__ds_scope, { Disclaimer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Disclaimer.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
/**
 * Текстовое поле с лейблом, подсказкой и состоянием ошибки.
 * Фокус — лунный акцент, всегда видимый.
 */
function Input({
  label,
  error,
  hint,
  id,
  type = 'text',
  placeholder,
  value,
  defaultValue,
  onChange,
  disabled = false,
  autoComplete,
  style
}) {
  const inputId = id || (label ? `e-input-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    className: "e-field",
    style: style
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "e-field__label",
    htmlFor: inputId
  }, label), /*#__PURE__*/React.createElement("input", {
    id: inputId,
    className: `e-input${error ? ' e-input--error' : ''}`,
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    autoComplete: autoComplete,
    "aria-invalid": error ? 'true' : undefined
  }), error && /*#__PURE__*/React.createElement("p", {
    className: "e-field__error",
    role: "alert"
  }, error), !error && hint && /*#__PURE__*/React.createElement("p", {
    className: "e-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// ui_kits/landing/LandingPage.jsx
try { (() => {
/**
 * Главная страница EMDR42 — «Лунная ночь».
 * Иконки — lucide (data-lucide), createIcons() вызывает хост-страница.
 */

function LucideIcon({
  name
}) {
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": name
  });
}
function LandingNav() {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return /*#__PURE__*/React.createElement("nav", {
    className: `l-nav${scrolled ? ' l-nav--scrolled' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container l-nav__inner"
  }, /*#__PURE__*/React.createElement("a", {
    className: "l-logo",
    href: "#",
    "aria-label": "EMDR-AI \u2014 \u0433\u043B\u0430\u0432\u043D\u0430\u044F"
  }, /*#__PURE__*/React.createElement("span", {
    className: "l-logo__mark",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    className: "l-logo__word"
  }, "EMDR-AI")), /*#__PURE__*/React.createElement("div", {
    className: "l-nav__links"
  }, /*#__PURE__*/React.createElement("a", {
    className: "l-nav__link l-nav__link--about",
    href: "#about"
  }, "\u041E \u043F\u0440\u043E\u0435\u043A\u0442\u0435"), /*#__PURE__*/React.createElement("a", {
    className: "l-nav__link",
    href: "#login"
  }, "\u0412\u043E\u0439\u0442\u0438"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    href: "#register"
  }, "\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F"))));
}
function LandingHero() {
  return /*#__PURE__*/React.createElement("header", {
    className: "l-hero",
    "data-screen-label": "Hero \u2014 \u041B\u0443\u043D\u043D\u0430\u044F \u043D\u043E\u0447\u044C"
  }, /*#__PURE__*/React.createElement("span", {
    className: "l-hero__moon",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    className: "l-hero__path",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "l-container l-hero__inner"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "l-hero__title"
  }, "EMDR-AI \u0422\u0435\u0440\u0430\u043F\u0438\u044F"), /*#__PURE__*/React.createElement("p", {
    className: "l-hero__sub"
  }, "\u041F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430 \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0439 EMDR-\u0442\u0435\u0440\u0430\u043F\u0438\u0438 \u0441 \u0418\u0418-\u0430\u0441\u0441\u0438\u0441\u0442\u0435\u043D\u0442\u043E\u043C \u0438 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u0432\u0430\u043D\u0438\u0435\u043C \u044D\u043C\u043E\u0446\u0438\u0439 \u0432 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0438"), /*#__PURE__*/React.createElement("div", {
    className: "l-hero__cta"
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "lg",
    href: "#session"
  }, "\u041D\u0430\u0447\u0430\u0442\u044C \u0441\u0435\u0441\u0441\u0438\u044E"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "ghost",
    size: "lg",
    href: "#about"
  }, "\u0423\u0437\u043D\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435")), /*#__PURE__*/React.createElement("div", {
    className: "l-disclaimer"
  }, /*#__PURE__*/React.createElement(__ds_scope.Disclaimer, null))));
}
const FEATURES = [{
  icon: 'shield',
  title: 'Приватность прежде всего',
  text: 'Распознавание эмоций работает локально в браузере. Видео не покидает ваше устройство.'
}, {
  icon: 'waves',
  title: 'Адаптивная терапия',
  text: 'ИИ подбирает паттерны и интенсивность BLS на основе ваших реальных эмоциональных реакций.'
}, {
  icon: 'audio-lines',
  title: 'Мультисенсорный подход',
  text: 'Визуальная стимуляция в сочетании с билатеральным аудио для усиления терапевтического эффекта.'
}, {
  icon: 'activity',
  title: 'Отслеживание прогресса',
  text: 'Детальная аналитика SUDS/VOC, эмоциональных трендов и истории сессий.'
}, {
  icon: 'sparkles',
  title: 'Геймификация',
  text: 'Система достижений и уровней делает процесс терапии вовлекающим.'
}, {
  icon: 'heart-pulse',
  title: 'Клинически обоснованно',
  text: 'Протокол EMDRIA из 8 фаз со встроенными механизмами безопасности и crisis-детекцией.'
}];
function LandingFeatures() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-features",
    id: "about",
    "data-screen-label": "\u041F\u043E\u0447\u0435\u043C\u0443 EMDR-AI"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "l-features__title"
  }, "\u041F\u043E\u0447\u0435\u043C\u0443 EMDR-AI"), /*#__PURE__*/React.createElement("div", {
    className: "l-features__grid"
  }, FEATURES.map(f => /*#__PURE__*/React.createElement(__ds_scope.Card, {
    key: f.title,
    icon: /*#__PURE__*/React.createElement(LucideIcon, {
      name: f.icon
    }),
    title: f.title
  }, f.text)))));
}
function LandingCta() {
  return /*#__PURE__*/React.createElement("section", {
    className: "l-cta",
    "data-screen-label": "CTA \u2014 \u043F\u0443\u0442\u044C \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F"
  }, /*#__PURE__*/React.createElement("span", {
    className: "l-cta__path",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "l-cta__title"
  }, "\u0413\u043E\u0442\u043E\u0432\u044B \u043D\u0430\u0447\u0430\u0442\u044C \u043F\u0443\u0442\u044C \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F?"), /*#__PURE__*/React.createElement("p", {
    className: "l-cta__sub"
  }, "\u041F\u0440\u0438\u0441\u043E\u0435\u0434\u0438\u043D\u044F\u0439\u0442\u0435\u0441\u044C \u043A \u0442\u0435\u043C, \u043A\u0442\u043E \u043D\u0430\u0448\u0451\u043B \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443 \u0447\u0435\u0440\u0435\u0437 \u043D\u0430\u0448\u0443 \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0443."), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "lg",
    href: "#register"
  }, "\u041F\u043E\u043F\u0440\u043E\u0431\u043E\u0432\u0430\u0442\u044C \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E")));
}
function LandingFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    className: "l-footer",
    "data-screen-label": "Footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "l-container"
  }, /*#__PURE__*/React.createElement("p", null, "\xA9 ", new Date().getFullYear(), " EMDR-AI Therapy Assistant"), /*#__PURE__*/React.createElement("div", {
    className: "l-footer__links"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#terms"
  }, "\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u044F"), /*#__PURE__*/React.createElement("a", {
    href: "#privacy"
  }, "\u041F\u043E\u043B\u0438\u0442\u0438\u043A\u0430 \u043A\u043E\u043D\u0444\u0438\u0434\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438"), /*#__PURE__*/React.createElement("a", {
    href: "#consent"
  }, "\u0418\u043D\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0435"), /*#__PURE__*/React.createElement("a", {
    href: "#about"
  }, "\u041E \u043F\u0440\u043E\u0435\u043A\u0442\u0435"))));
}
function LandingPage() {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons({
      attrs: {
        'stroke-width': 1.5
      }
    });
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "l-page"
  }, /*#__PURE__*/React.createElement(LandingNav, null), /*#__PURE__*/React.createElement(LandingHero, null), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(LandingFeatures, null), /*#__PURE__*/React.createElement(LandingCta, null)), /*#__PURE__*/React.createElement(LandingFooter, null));
}
Object.assign(__ds_scope, { LandingNav, LandingHero, LandingFeatures, LandingCta, LandingFooter, LandingPage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/landing/LandingPage.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Disclaimer = __ds_scope.Disclaimer;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.LandingNav = __ds_scope.LandingNav;

__ds_ns.LandingHero = __ds_scope.LandingHero;

__ds_ns.LandingFeatures = __ds_scope.LandingFeatures;

__ds_ns.LandingCta = __ds_scope.LandingCta;

__ds_ns.LandingFooter = __ds_scope.LandingFooter;

__ds_ns.LandingPage = __ds_scope.LandingPage;

})();
